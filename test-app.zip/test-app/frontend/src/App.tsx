import logo from './logo.svg';
import './App.css';
import { useQuery } from 'react-query'

function App() {
  async function fetchingMessage() {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({name: "test"})
    };
    const resp = await fetch(process.env.REACT_APP_API_URL+  '/hello', requestOptions);
    const { message } = await resp.json();
    return message;
  }

  const { data } = useQuery('query-message', fetchingMessage)
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          {data}
        </p>
        <h1 className="text-3xl text-blue-600 font-bold">
          Hello tailwind!
        </h1>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
