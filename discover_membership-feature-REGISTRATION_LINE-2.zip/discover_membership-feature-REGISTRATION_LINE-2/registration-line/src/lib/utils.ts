import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// URLのクエリパラメータを取得する関数
export const checkQueryParamValue = (paramName: string, expectedValue: string): boolean => {
  const getQueryParam = (name: string): string | null => {
    const urlSearchParams = new URLSearchParams(window.location.search);
    return urlSearchParams.get(name);
  };

  // 実際の値を取得
  const actualValue = getQueryParam(paramName);

  // クエリパラメータの値と期待される値を比較して真偽値を返す
  return actualValue === expectedValue;
};
