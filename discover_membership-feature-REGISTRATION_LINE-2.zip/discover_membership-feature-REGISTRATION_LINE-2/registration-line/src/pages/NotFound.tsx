import { Button } from "@/components/ui/button"
import { useNavigate } from 'react-router-dom';


function NotFound(){
  const navigate = useNavigate();

  return (
    <>
      <div className="h-screen flex items-center justify-center">
        <div className="p-3 text-center space-y-4">
          <h1 className="mb-4 text-6xl font-semibold text-blue-600">404</h1>
          <p className="mb-4 text-2xl font-semibold  text-gray-600">ご指定のページが見つかりませんでした。</p>
          <Button variant="outline" onClick={() => navigate(-1)}>戻る</Button>
        </div>
      </div>
    </>
  )
}

export default NotFound;