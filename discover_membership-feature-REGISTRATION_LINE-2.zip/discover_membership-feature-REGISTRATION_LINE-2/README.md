# discover_membership
LPと登録導線のシステム

# 開発準備

## テスト用の設定ファイルをコピーします

```bash
cp frontend/.env.example frontend/.env
```

## まず docker をビルドします

```bash
docker-compose build
```

## 次にコンテナを全て立ち上げ

```bash
docker-compose up -d
```

## apiコンテナに入ります

```bash
docker exec -it discover_membership_api bash
```

## 下記のコマンドを実行し、開発の準備を行います

```bash
npm install
sls offline start --host 0.0.0.0
```

## clientコンテナに入ります

```bash
docker exec -it discover_membership_client bash
```

## 下記のコマンドを実行し、開発の準備を行います

```bash
npm install
npm start
```

```bash
npm install
sls offline start --host 0.0.0.0
```

## registration-lineコンテナに入ります

```bash
docker exec -it registration-line bash
```

## 下記のコマンドを実行し、開発の準備を行います

```bash
npm install
npm start
```

# デプロイ方法
NASにある鍵の場所:
```bash
\\10.10.10.150\share\Engineer\AWS-SES-KEY\LPデプロイ用
```

## ステージング環境デプロイ
認証情報:
```bash
\\10.10.10.150\share\Engineer\AWS-SES-KEY\LPデプロイ用\開発環境用アクセスキー.csv
```

### clientデプロイ
```bash
npm run build
aws s3 sync build/. s3://stg-lp/plaio
aws cloudfront create-invalidation --distribution-id E12OJ3BBJZ43ZD --paths "/*"
```

### 登録導線デプロイ
```bash
npm run build
aws s3 sync build/. s3://stg-lp/registration-line
aws cloudfront create-invalidation --distribution-id E39VEGXG0XG0ZS --paths "/*"
```

### apiデプロイ
```bash
sls deploy --region ap-northeast-1
```

## 本番環境デプロイ
認証情報:
```bash
\\10.10.10.150\share\Engineer\AWS-SES-KEY\LPデプロイ用\本番環境用アクセスキー.csv
```

### clientデプロイ
```bash
npm run build
aws s3 sync build/. s3://production-lp/plaio
aws cloudfront create-invalidation --distribution-id E1VXT3KHBD1N7V --paths "/*"
```

### apiデプロイ
```bash
sls deploy --region ap-northeast-1
```
