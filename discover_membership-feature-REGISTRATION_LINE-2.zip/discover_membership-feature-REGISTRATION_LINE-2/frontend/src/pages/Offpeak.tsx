import { useEffect } from "react";
import $ from 'jquery'
import ApplyButtonFirst from "../components/offpeak/ApplyButtonFirst";
import ApplyButtonSecond from "../components/offpeak/ApplyButtonSecond";

function Offpeak(){
  require("../assets/css/lp/offpeak/style.css");

  useEffect(() => {
    const pagetop = $('#btn-kochira');
    pagetop.hide();

    const scrollHandler = () => {
      if (window.scrollY > 20) {
        pagetop.fadeIn();
      } else {
        pagetop.fadeOut();
      }
    }
    window.addEventListener("scroll", scrollHandler);

    $(".accordion-title").on("click", function () {
      $(this).next().slideToggle(300);
      $(this).toggleClass("open");
    });

    return () => {
      window.removeEventListener("scroll", scrollHandler);
      $(".accordion-title").off('click')
    };

  },[])

  return (
    <>
    <section id="mv">
      <div className="logo">
        <img src={require("../assets/images/lp/offpeak/logo.png")} width="100%" alt="センターモバイル" />
      </div>
      <div className="mv-bar pc">
        クレカがなくても大丈夫！<span>後払い決済</span>対応！
      </div>
      <div className="mv-inner">
        <div className="mv-pc">
          <img
            src={require("../assets/images/lp/offpeak/mv-pc.png")}
            width="100%"
            alt="スマホ代がさらにオトク！"
          />
        </div>
        <div className="mv-sp">
          <img
            src={require("../assets/images/lp/offpeak/mv-sp.jpg")}
            width="100%"
            alt="スマホ代がさらにオトク！"
          />
        </div>
        <ApplyButtonFirst urlPram={true} />
      </div>
    </section>
    <section id="intro">
      <div className="container">
        <div className="intro-ttl">
          <p>
            <span>医療関係・飲食店の方など、</span>
          </p>
          <p>
            <span>オフピーク時に利用する方へ！</span>
          </p>
        </div>
        <h2>
          オフピークプランなら
          <br className="sp" />
          <span>こんなにお得！</span>
        </h2>
        <table width="100%" border={0}>
          <tbody>
            <tr>
              <th scope="col">容量</th>
              <th scope="col">オフピークプラン</th>
              <th scope="col">通常プラン</th>
            </tr>
            <tr>
              <td>3GB</td>
              <td>
                <span>935</span>円(税込)
                <div className="off">
                  33<span>%</span>
                  <br />
                  OFF
                </div>
              </td>
              <td>
                <span>1,408</span>円(税込)
              </td>
            </tr>
            <tr>
              <td>12GB</td>
              <td>
                <span>1,518</span>円(税込)
                <div className="off">
                  22<span>%</span>
                  <br />
                  OFF
                </div>
              </td>
              <td>
                <span>1,958</span>円(税込)
              </td>
            </tr>
            <tr>
              <td>20GB</td>
              <td>
                <span>2,134</span>円(税込)
                <div className="off">
                  21<span>%</span>
                  <br />
                  OFF
                </div>
              </td>
              <td>
                <span>2,728</span>円(税込)
              </td>
            </tr>
            <tr>
              <td>50GB</td>
              <td>
                <span>3,234</span>円(税込)
                <div className="off">
                  26<span>%</span>
                  <br />
                  OFF
                </div>
              </td>
              <td>
                <span>4,378</span>円(税込)
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
    <section id="about">
      <h2>
        <img
          src={require("../assets/images/lp/offpeak/about-title.png")}
          width={1178}
          height={212}
          alt="オフピークプランとは"
        />
      </h2>
      <div className="container">
        <div className="about-inner">
          <p className="text1">
            通常のピークタイムとズレた時間に
            <br />
            利用をする人がお得なプランです
          </p>
          <img
            src={require("../assets/images/lp/offpeak/about-time.png")}
            width={1760}
            height={303}
            alt=""
            className="pc"
          />
          <img src={require("../assets/images/lp/offpeak/about-time-sp.png")} alt="" className="sp" />
          <p className="text2">時間帯により速度上限があります</p>
          <ul>
            <li>
              <div className="time">12~13時の1時間だけ</div>
              <div className="speed">256kbps</div>
            </li>
            <li>
              <div className="time">17~19時の2時間だけ</div>
              <div className="speed">512kbps</div>
            </li>
          </ul>
          <p className="text3">その他の時間は速度上限なしの高速通信</p>
        </div>
        <p className="text4">※ベストエフォート方式です</p>
      </div>
    </section>
    <section id="for">
      <div className="container">
        <h2>
          <span className="text1">
            オフピークプラン
          </span>
          <span className="text2">は</span>
          <br className="sp" />
          こんな方におすすめ
        </h2>
        <div className="times">
          <div className="time">
            <div className="clock">
              <img src={require("../assets/images/lp/offpeak/times-icon1.png")} width="100%" alt="" />
            </div>
            <p>
              12−13時･17−19時に
              <br />
              スマホをあんまり
              <br />
              使わない
            </p>
          </div>
          <div className="time">
            <div className="clock">
              <img src={require("../assets/images/lp/offpeak/times-icon2.png")} width="100%" alt="" />
            </div>
            <p>
              賢くオトクに
              <br />
              利用したい
            </p>
          </div>
        </div>
        <div className="for-inner">
          <div className="names">
            <div className="name">
              <img src={require("../assets/images/lp/offpeak/for-time1.png")} width={150} height={150} alt="" />
              <p className="katagaki">カフェ店員</p>
              <p className="text">
                飲食店で働いているので、12-13時や17-19時はスマホを使わない
              </p>
            </div>
            <div className="name">
              <img src={require("../assets/images/lp/offpeak/for-time2.png")} width={150} height={150} alt="" />
              <p className="katagaki">夜勤メイン</p>
              <p className="text">
                夜の18時～朝まで仕事で、お昼は寝ていることが多い
              </p>
            </div>
            <div className="name">
              <img src={require("../assets/images/lp/offpeak/for-time3.png")} width={150} height={150} alt="" />
              <p className="katagaki">主婦</p>
              <p className="text">
                お昼は家のWi-Fi、17-19時は家事や子供の世話をしている
              </p>
            </div>
            <div className="name">
              <img src={require("../assets/images/lp/offpeak/for-time4.png")} width={150} height={150} alt="" />
              <p className="katagaki">在宅ワーカー</p>
              <p className="text">
                テレワークOKの職場なので、家のWi-Fiをメインで利用している
              </p>
            </div>
          </div>
          <h3>256kbpsと512kbpsでできること</h3>
          <table width="100%%" border={0}>
            <tbody>
              <tr>
                <th scope="row">&nbsp;</th>
                <td className="day">
                  12-13時だけ
                  <br className="sp" />
                  <span>256kbps</span>
                </td>
                <td className="night">
                  17-19時だけ
                  <br className="sp" />
                  <span>512kbps</span>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  メール・LINEなど
                  <br className="sp" />
                  テキストのやりとり
                </th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon1.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  メール・LINEなど
                  <br className="sp" />
                  動画・写真の送信
                </th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon3.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">LINE通話などIP電話</th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">テレビ電話</th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon4.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  SNS
                  <br className="sp" />
                  （動画・写真）
                </th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon3.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  動画視聴
                  <br className="sp" />
                  （低画質 144p）
                </th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon3.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  動画視聴
                  <br className="sp" />
                  （標準画質 360p）
                </th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon4.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">音楽ストリーミング</th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon3.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon2.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  画像の多い
                  <br className="sp" />
                  WEBサイトの閲覧
                </th>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon1.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
                <td>
                  <img
                    src={require("../assets/images/lp/offpeak/time-icon1.png")}
                    width={60}
                    height={60}
                    alt=""
                  />
                </td>
              </tr>
            </tbody>
          </table>
          <p className="kome">
            あくまでも利用の目安であり、通信環境やご利用サービスによって利用できない場合があります。
          </p>
        </div>
      </div>
    </section>
    <section id="monitor">
      <div className="container monitor-inner">
        <h3>
          <span>速度上限って実際どうなの？</span>
        </h3>
        <h2 style={{margin: "revert"}}>
          モニターさんに
          <br className="sp" />
          試しに使ってもらいました！
        </h2>
        <div className="names">
          <div className="name">
            <p className="katagaki">Y.Hさん</p>
            <p className="text">
              すごくお得なプランにも関わらず、遅いなと感じる時間が
              <span className="bold1">お昼の1時間だけ</span>
              なので、ランチの時間をずらせば気になりません。
            </p>
          </div>
          <div className="name">
            <p className="katagaki">T.Sさん</p>
            <p className="text">
              速度に上限がかかる通勤時間に使っているのですが、
              <span className="bold1">
                ニュースサイトやLINEなどは普通に見れる
              </span>
              ため、支障なく使えています。
            </p>
          </div>
          <div className="name">
            <p className="katagaki">N.Mさん</p>
            <p className="text">
              正直、思ったより普通に使えます。重い動画はダウンロードして観る派なので、
              <span className="bold1">普通のSIMとなんら変わりなく</span>
              使えてます。
            </p>
          </div>
          <div className="name">
            <p className="katagaki">Y.Kさん</p>
            <p className="text">
              フレックスな仕事をしているため平日は問題ないです。休日は
              <span className="bold2">お昼の時間帯にも使うので少し不便</span>
              に感じる時もありますが思った以上にストレスはありませんでした。
            </p>
          </div>
        </div>
      </div>
    </section>
    <section id="price">
      <div className="container">
        <h2>料金・プラン</h2>
        <div className="kakehoudai">
          <h4>10分以上電話するなら</h4>
          <h3>
            24時間
            <img src={require("../assets/images/lp/offpeak/price-icon.png")} />
            かけ放題セット
          </h3>
          <div className="setprice">
            <div className="houdai">
              20GB+
              <br />
              <span>かけ放題</span>
            </div>
            <p className="price">
              <span>3,300</span>円(税込)
            </p>
          <ApplyButtonFirst/>
          </div>
        </div>
        <table width="100%%" border={0}>
          <tbody>
            <tr>
              <th scope="col">容量</th>
              <th colSpan={2} scope="col">
                料金
              </th>
            </tr>
            <tr>
              <td>3GB</td>
              <td>
                <span>935</span>円(税込)
              </td>
              <td>
                通常プランより
                <br />
                33%オトク！
              </td>
            </tr>
            <tr>
              <td>12GB</td>
              <td>
                <span>1,518</span>円(税込)
              </td>
              <td>
                通常プランより
                <br />
                22%オトク！
              </td>
            </tr>
            <tr>
              <td>20GB</td>
              <td>
                <span>2,134</span>円(税込)
              </td>
              <td>
                通常プランより
                <br />
                21%オトク！
              </td>
            </tr>
            <tr>
              <td>50GB</td>
              <td>
                <span>3,234</span>円(税込)
              </td>
              <td>
                通常プランより
                <br />
                26%オトク！
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
    <section id="option">
      <div className="container">
        <h2>オプション</h2>
        <h3>かけ放題オプション</h3>
        <table width="100%%" border={0}>
          <tbody>
            <tr>
              <th scope="row">5分かけ放題</th>
              <td>
                <span>990</span>円(税込)
              </td>
            </tr>
            <tr>
              <th scope="row">10分かけ放題</th>
              <td>
                <span>1,100</span>円(税込)
              </td>
            </tr>
            <tr>
              <th scope="row">24時間かけ放題</th>
              <td>
                <span>2,640</span>円(税込)
              </td>
            </tr>
          </tbody>
        </table>
        <p>
          ※10分かけ放題は10分超過後は11円/30秒の通話料が発生します。※【緊急通報】110、118、119【電話番号案内】104
          【発信者番号通知】184、186【クイックダイヤル】＃ダイヤル【ガスコンロダイヤル】1416【他
          フリーダイヤル】0120、0800【ナビダイヤル】0570など一部かけ放題対象外番号があります。
        </p>
        <h3>その他オプション</h3>
        <table width="100%%" border={0}>
          <tbody>
            <tr>
              <th scope="row">ギガ追加購入</th>
              <td>
                <span>550</span>円(税込)
              </td>
            </tr>
            <tr>
              <th scope="row">10分かけ放題</th>
              <td>
                <span>330</span>円(税込)
              </td>
            </tr>
            <tr>
              <th scope="row">24時間かけ放題</th>
              <td>
                <span>330</span>円(税込)
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
    <section id="feature">
      <div className="container">
        <h2>センターモバイルの特徴</h2>
        <div className="points">
          <div className="point">
            <div className="step">1</div>
            <img src={require("../assets/images/lp/offpeak/feature-step1.png")} />
            <h3>
              新規も、乗り換えも
              <br />
              今のスマホをそのまま
            </h3>
            <p className="text">
              ご契約後、SIMを入れ替えるだけ！
              <br />
              アプリもデータも連絡先も、
              <br className="sp" />
              そのまま使えます！
            </p>
          </div>
          <div className="point">
            <div className="step">2</div>
            <img src={require("../assets/images/lp/offpeak/feature-step2.png")} />
            <h3>
              最短即日開通が可能！
              <br />
              eSIM対応
            </h3>
            <p className="text">
              オンラインで簡単手続き！
              <br className="sp" />
              最短でその日から使えるeSIMに対応しています。
            </p>
          </div>
          <div className="point">
            <div className="step">3</div>
            <img src={require("../assets/images/lp/offpeak/feature-step3.png")} />
            <h3>
              ポイントを貯めて
              <br />
              携帯料金がオトクに！
            </h3>
            <p className="text">
              アプリで貯めたポイントを、１ポイント１円で携帯料金に使用できます。
            </p>
          </div>
          <div className="point">
            <div className="step">4</div>
            <img src={require("../assets/images/lp/offpeak/feature-step4.png")} />
            <h3>
              docomo回線だから
              <br />
              全国エリア対応！
            </h3>
            <p className="text">
              センターモバイルはdocomo回線だから安心！快適に使えるSIMです。
            </p>
          </div>
          <div className="point">
            <div className="step">5</div>
            <img src={require("../assets/images/lp/offpeak/feature-step5.png")} />
            <h3>
              専用アプリなしで
              <br />
              かけ放題が使える！※
            </h3>
            <p className="text">
              専用アプリ不要で通話ができます。
              <br />
              <span>※ご契約プランによりかけ放題の時間は異なります。</span>
            </p>
          </div>
        </div>
        <p className="more">
          さらに、専用アプリでポイントを貯めればもっとオトクに利用できます！
        </p>
        <div className="btn">
          <a href="#poikatsu">ポイントの貯め方はこちら</a>
        </div>
      </div>
    </section>
    <section id="poikatsu">
      <div className="container">
        <h3>ポイ活で、スマホ代をさらに節約</h3>
        <h2>ポイントの貯め方はいろいろ！</h2>
        <div className="poikatsus">
          <div className="poikatsu">
            <div className="step">
              <img src={require("../assets/images/lp/offpeak/poikatsu-icon.png")} width={28} height={28} />
            </div>
            <h4>
              <span>例えば…</span>
              <br className="sp" />
              動画視聴で
              <br className="sp" />
              貯まる！
            </h4>
            <p className="text">アプリ内の動画広告を見るだけでポイントGET</p>
          </div>
          <div className="poikatsu">
            <div className="step">
              <img src={require("../assets/images/lp/offpeak/poikatsu-icon.png")} width={28} height={28} />
            </div>
            <h4>
              <span>例えば…</span>
              <br className="sp" />
              ガチャを回して
              <br className="sp" />
              貯まる！！
            </h4>
            <p className="text">
              動画を見てガチャを回せば、大量ポイントGETも可能
            </p>
          </div>
        </div>
        <p className="more">
          他にもアプリDLやサービス申込で大量ポイント獲得が可能
        </p>
        <div className="waku waku2 bg1">
          <div className="youtube">
            <iframe
              width="100%"
              height={315}
              src="https://www.youtube.com/embed/bvcCBO0gYZI?si=esFyFJUgp31qz_B0"
              title="YouTube video player"
              frameBorder={0}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen={true}
            />
          </div>
        </div>
      </div>
    </section>
    <section id="pointget">
      <div className="container">
        <div className="pointget-inner">
          <h3>もっと簡単に貯めるなら</h3>
          <h2>
            <span className="kome02">データ容量無制限！</span>
            <br />
            <span className="kome01">
              5Gの最新機種に申し込みで
              <br className="sp" />
              お得にポイントGET！
            </span>
          </h2>
          <div className="cashback">
            <div className="cashback-ttl">
              <img
                className="pc"
                src={require("../assets/images/lp/offpeak/pointget-ttl.png")}
                alt="お乗り換えなら最大40,000円キャッシュバック"
              />
              <img
                className="sp"
                src={require("../assets/images/lp/offpeak/pointget-ttl-sp.png")}
                alt="お乗り換えなら最大40,000円キャッシュバック"
              />
            </div>
            <div className="cashback-content">
              <div className="cashback-inner">
                <div className="cashback-main">
                  <img className="pc" src={require("../assets/images/lp/offpeak/pointget-main.png")} alt="" />
                  <img className="sp" src={require("../assets/images/lp/offpeak/pointget-main-sp.png")} alt="" />
                </div>
                <div className="btn">
                  <a href="https://wimax.plaio.jp" target="_blank">
                    PLAIO WiMAXに申し込む
                  </a>
                </div>
                <div className="cashback-note pc">
                  <img
                    src={require("../assets/images/lp/offpeak/pointget-note.png")}
                    alt="※1 一部エリアで提供。※2 スタンダードモードの場合(800MHz非対応)"
                  />
                </div>
              </div>
            </div>
            <div className="cashback-note sp">
              <img
                src={require("../assets/images/lp/offpeak/pointget-note-sp.png")}
                alt="※1 一部エリアで提供。※2 スタンダードモードの場合(800MHz非対応)"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
    <section id="flow">
      <div className="container">
        <h2>
          オンラインで簡単！
          <br />
          ご契約の流れ
        </h2>
        <ul>
          <li>
            <div className="list">
              <div className="icon step01">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width={78}
                  height={92}
                  viewBox="0 0 78 92"
                  fill="none"
                >
                  <path
                    d="M27.0469 72H5.658C3.63732 72 2 70.3632 2 68.3431V5.6569C2 3.63682 3.63732 2 5.658 2H40.3931C42.4137 2 44.0511 3.63682 44.0511 5.6569V13.5456"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M2.27148 9.44971H43.7794"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M2 59.2493H27.0469"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M21.1924 65.6206H24.8504"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M76 85.9935V23.3073C76 21.2876 74.3623 19.6504 72.342 19.6504L37.6069 19.6504C35.5867 19.6504 33.9489 21.2876 33.9489 23.3073L33.9489 85.9935C33.9489 88.0131 35.5867 89.6504 37.6069 89.6504H72.342C74.3623 89.6504 76 88.0131 76 85.9935Z"
                    stroke="#46BDFF"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M34.2205 27.0999H75.7364"
                    stroke="#46BDFF"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M33.9563 76.8997H75.9994"
                    stroke="#46BDFF"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M53.1497 83.271H56.8077"
                    stroke="#46BDFF"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div className="stepText">
                <span>STEP.1</span>
                <p>お手持ちのスマホまたは新しいスマホの準備</p>
              </div>
            </div>
          </li>
          <li>
            <div className="list">
              <div className="icon step02">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width={78}
                  height={52}
                  viewBox="0 0 78 52"
                  fill="none"
                >
                  <path
                    d="M71.6058 2.41406H6.3942C3.96735 2.41406 2 4.39352 2 6.83531V45.2241C2 47.6659 3.96735 49.6453 6.3942 49.6453H71.6058C74.0326 49.6453 76 47.6659 76 45.2241V6.83531C76 4.39352 74.0326 2.41406 71.6058 2.41406Z"
                    fill="white"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M70.5339 16.4036H49.9075V42.0063H70.5339V16.4036Z"
                    fill="#46BDFF"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M65.8658 33.3867C65.6029 32.946 65.2628 32.5604 64.8712 32.2299C64.2828 31.736 63.5768 31.365 62.7936 31.1116C62.733 31.0914 62.6668 31.0786 62.6043 31.0602C63.0308 30.8289 63.4206 30.5387 63.7589 30.199C64.6634 29.2993 65.226 28.0396 65.226 26.6643C65.226 25.2889 64.6634 24.0293 63.7589 23.1295C62.858 22.2279 61.5967 21.6642 60.2197 21.666C58.8426 21.666 57.5814 22.2279 56.6805 23.1295C55.776 24.0293 55.2134 25.2889 55.2134 26.6643C55.2134 28.0396 55.776 29.2993 56.6805 30.199C57.0188 30.5369 57.4067 30.827 57.8314 31.0584C56.7982 31.3614 55.89 31.8645 55.195 32.5788C54.8402 32.946 54.546 33.3702 54.3382 33.844C54.1323 34.3177 54.0165 34.8392 54.0183 35.3736V40.5462C54.0183 40.9319 54.1746 41.3065 54.4467 41.5801C54.7188 41.8537 55.0957 42.0079 55.4818 42.0079H64.9594C65.3437 42.0079 65.7206 41.8518 65.9945 41.5801C66.2684 41.3083 66.4229 40.9319 66.4229 40.5462V35.3736C66.4229 34.6611 66.2188 33.9725 65.8676 33.3867H65.8658Z"
                    fill="white"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M7.92407 10.252H70.5333"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M7.92407 26.8887H44.3784"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M7.92407 33.8018H44.3784"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M7.92407 40.7151H44.3784"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M45.1677 16.4036H8.71338V21.0437H45.1677V16.4036Z"
                    fill="#46BDFF"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div className="stepText">
                <span>STEP.2</span>
                <p>本人確認書類の準備</p>
              </div>
            </div>
            <div className="link">
              <a href="https://maimo.app/identity" target="_blank">
                その他のご本人さま確認書類・注意事項はこちら
              </a>
            </div>
          </li>
          <li>
            <div className="list">
              <div className="icon step03">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width={74}
                  height={80}
                  viewBox="0 0 74 80"
                  fill="none"
                >
                  <g clipPath="url(#clip0_259_1963)">
                    <path
                      d="M67.0855 29.1687H6.9147C4.45671 29.1687 2.46411 31.1676 2.46411 33.6334V73.0593C2.46411 75.5251 4.45671 77.524 6.9147 77.524H67.0855C69.5435 77.524 71.5361 75.5251 71.5361 73.0593V33.6334C71.5361 31.1676 69.5435 29.1687 67.0855 29.1687Z"
                      stroke="#355CF3"
                      strokeWidth={4}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M54.2392 19.7621C54.2392 10.2159 46.5238 2.46875 37.0004 2.46875C27.477 2.46875 19.7617 10.2085 19.7617 19.7621V28.9926"
                      stroke="#355CF3"
                      strokeWidth={4}
                      strokeMiterlimit={10}
                      strokeLinecap="round"
                    />
                    <path
                      d="M43.9954 49.8308C43.9929 49.8308 43.9909 49.8287 43.9909 49.8262C43.9883 46.0522 40.861 43 36.9954 43C33.1283 43 30 46.0547 30 49.8308C30 52.3311 31.3839 54.5174 33.4404 55.7081C33.8233 55.9298 34.0649 56.3478 34.0076 56.7864L33.2122 62.8704C33.1339 63.469 33.6 64 34.2037 64H39.7963C40.4 64 40.8661 63.469 40.7878 62.8704L39.9924 56.7864C39.9351 56.3478 40.1767 55.9298 40.5596 55.7083C42.6148 54.5196 43.9983 52.3418 44 49.8354C44 49.8328 43.998 49.8308 43.9954 49.8308Z"
                      fill="#46BDFF"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_259_1963">
                      <rect width={74} height={80} fill="white" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
              <div className="stepText">
                <span>STEP.3</span>
                <p>
                  端末のSIMロック解除
                  <br />
                  とMNP予約番号の発行
                </p>
              </div>
            </div>
            <div className="dp_box">
              <input id="dp01" type="checkbox" />
              <label htmlFor="dp01" />
              <div className="dp_container">
                <h3>SIMロック解除</h3>
                <p className="m">
                  各キャリアで購入したスマートフォンはSIMロックがかかっているため、センターモバイル申込み前に解除が必要です。
                </p>
                <h3>【他社から乗り換え】MNP予約番号</h3>
                <p className="m">
                  電話番号をそのまま利用する場合は、有効期限が１１日以上残っているMNP予約番号が必要です。
                </p>
                <div className="pull-dwnlink">
                  <a href="https://maimo.app/inquiry/list/111" target="_blank">
                    MNPについてはこちら
                  </a>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div className="list">
              <div className="icon step04">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width={61}
                  height={78}
                  viewBox="0 0 61 78"
                  fill="none"
                >
                  <path
                    d="M59 71.8957C59 74.0217 57.2803 75.7471 55.1612 75.7471H14.3086L2 63.7649V5.85139C2 3.72532 3.71968 2 5.83882 2H55.1612C57.2803 2 59 3.72532 59 5.85139V71.8957Z"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M49.3083 11.1914H12.0665C11.532 11.1914 11.0986 11.6232 11.0986 12.156V43.3746C11.0986 43.9073 11.532 44.3391 12.0665 44.3391H49.3083C49.8429 44.3391 50.2762 43.9073 50.2762 43.3746V12.156C50.2762 11.6232 49.8429 11.1914 49.3083 11.1914Z"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M11.0986 21.4209H50.283"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinejoin="round"
                  />
                  <path
                    d="M20.8936 11.1914V21.421"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinejoin="round"
                  />
                  <path
                    d="M30.6875 11.1914V21.421"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinejoin="round"
                  />
                  <path
                    d="M40.4885 11.1914V21.421"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinejoin="round"
                  />
                  <path
                    d="M20.8936 34.1094V44.339"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinejoin="round"
                  />
                  <path
                    d="M30.6875 34.1094V44.339"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinejoin="round"
                  />
                  <path
                    d="M11.0986 34.1094H40.4886V44.339"
                    stroke="#355CF3"
                    strokeWidth={3}
                    strokeLinejoin="round"
                  />
                  <path
                    d="M21.2482 55.7696C20.0895 55.1991 18.8559 54.907 17.5609 54.8934C16.927 54.8934 16.4431 55.0157 16.1023 55.2602C15.7683 55.5047 15.5979 55.8376 15.5979 56.2519C15.5979 56.9312 16.1159 57.4202 17.1451 57.7191C18.9785 58.2218 20.2667 58.8195 21.0097 59.5191C21.7526 60.2188 22.1207 61.1154 22.1207 62.2158C22.1207 63.52 21.6776 64.5117 20.7916 65.1909C19.9055 65.8702 18.5969 66.2098 16.8724 66.2098C16.0954 66.2098 15.2912 66.0875 14.4528 65.8498C13.6213 65.6121 12.9193 65.3064 12.3604 64.9396L13.0965 62.4875C14.3438 63.3501 15.6388 63.7781 16.9951 63.7781C17.629 63.7781 18.1129 63.649 18.4401 63.3841C18.7673 63.1192 18.9308 62.7524 18.9308 62.2769C18.9308 61.883 18.8013 61.5637 18.5355 61.3192C18.2697 61.0746 17.8062 60.8573 17.1315 60.6671C15.4548 60.178 14.2483 59.5803 13.519 58.8738C12.7897 58.1674 12.4217 57.298 12.4217 56.2587C12.4217 55.0972 12.8579 54.1802 13.7303 53.4941C14.6028 52.8081 15.8296 52.4617 17.4177 52.4617C19.1081 52.4617 20.5735 52.7538 21.8208 53.3379L21.2278 55.7764L21.2482 55.7696Z"
                    fill="#46BDFF"
                  />
                  <path
                    d="M25.835 66.0324V52.6375H29.2702V66.0324H25.835Z"
                    fill="#46BDFF"
                  />
                  <path
                    d="M44.0138 57.827H43.9797L41.6282 62.9689H38.786L36.4345 57.827H36.4004V66.0324H33.4355V52.6375H36.6322L40.1901 60.5372H40.2241L43.7616 52.6375H47.0536V66.0324H44.0138V57.827Z"
                    fill="#46BDFF"
                  />
                </svg>
              </div>
              <div className="stepText">
                <span>STEP.4</span>
                <p>
                  SIMカードを受け取り
                  <br />
                  初期設定
                </p>
              </div>
            </div>
          </li>
          <li>
            <div className="list">
              <div className="icon step05">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width={59}
                  height={96}
                  viewBox="0 0 59 96"
                  fill="none"
                >
                  <g clipPath="url(#clip0_259_2023)">
                    <path
                      d="M52.0723 46.9553C50.2229 46.9553 48.6001 45.3925 48.1243 43.1563C47.8326 41.7838 48.0478 40.4199 48.7162 39.414C49.2373 38.6297 49.9879 38.1268 50.8857 37.9591C51.4889 37.8483 53.0353 37.5869 54.3296 37.5869C55.3322 37.5869 56.0034 37.7404 56.3801 38.0529C57.2297 38.7576 57.8245 39.7322 58.0511 40.795C58.2975 41.96 58.0851 43.1562 57.4478 44.1621C56.8134 45.1623 53.7207 46.7053 52.7011 46.8957C52.4915 46.9354 52.2819 46.9525 52.0752 46.9525L52.0723 46.9553Z"
                      fill="white"
                    />
                    <path
                      d="M52.0726 47.8087C49.8182 47.8087 47.8526 45.9674 47.2947 43.3333C46.9548 41.7364 47.2182 40.1366 48.0112 38.9404C48.6627 37.96 49.6029 37.3321 50.733 37.1218C51.5118 36.9769 53.0185 36.7354 54.3327 36.7354C55.5562 36.7354 56.3803 36.9456 56.9241 37.3974C57.9211 38.2243 58.6178 39.3694 58.884 40.6197C59.1785 42.0063 58.9236 43.4271 58.1675 44.6205C57.3348 45.9361 53.8937 47.5416 52.8571 47.7348C52.5994 47.7831 52.336 47.8058 52.0754 47.8058L52.0726 47.8087ZM54.3298 39.2387C53.1715 39.2387 51.7441 39.4802 51.1833 39.5825C50.733 39.6649 50.3535 39.9264 50.0816 40.3298C49.6567 40.9663 49.5293 41.8699 49.7304 42.8133C50.0419 44.2824 51.0134 45.3053 52.0896 45.3053C52.1915 45.3053 52.2963 45.2968 52.4011 45.2769C53.214 45.1263 55.7771 43.7283 56.0603 43.2822C56.4653 42.6428 56.6013 41.8841 56.4455 41.1425C56.2982 40.4549 55.9159 39.8212 55.3664 39.3524C55.3013 39.3268 55.0237 39.2387 54.3298 39.2387Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M9.50239 91.7202L9.6355 91.2912C10.2671 89.2311 10.6636 86.9494 11.0459 84.7387C11.349 82.9826 11.6379 81.3175 12.0344 79.7604C8.09479 74.9469 4.62254 66.8202 3.40187 62.5352L3.39054 62.4954V62.4528C3.09599 58.2275 5.26828 45.7448 6.06412 43.9376C7.84556 39.897 13.1616 33.1172 28.7386 33.1172C33.8422 33.1172 39.3791 33.927 43.9304 35.3364C45.2275 35.737 46.3349 36.8481 47.227 38.6382C50.3651 44.9293 50.249 58.506 46.9778 67.6897C44.6441 74.2422 37.6599 79.1494 32.1457 82.133C31.4603 85.0939 30.7013 88.2905 30.0555 90.936C29.3928 93.6468 28.9878 95.0382 28.8405 95.1101L28.7244 95.167L9.50522 91.7231L9.50239 91.7202Z"
                      fill="white"
                    />
                    <path
                      d="M27.9023 93.7605C27.9533 93.7207 28.0128 93.6809 28.0779 93.6468L28.1176 93.627L28.4659 94.343L28.0808 93.6554L28.4518 94.3515C28.4291 94.3629 28.4065 94.3771 28.3866 94.3942L27.9023 93.7633V93.7605Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M28.667 95.9995C28.1912 95.9995 27.7494 95.7211 27.5426 95.292C27.3897 94.9709 27.3784 94.6015 27.5115 94.2747C27.7211 93.5814 29.1088 87.9723 30.5816 81.5846C30.6637 81.2323 30.8903 80.9339 31.2075 80.7634C35.5322 78.4391 43.1338 73.5773 45.4278 67.1328C48.5178 58.4548 48.6735 45.222 45.7536 39.3713C45.0682 37.9989 44.2921 37.1692 43.4397 36.9077C41.358 36.2627 35.7588 34.7624 28.7038 34.7624C26.7666 34.7624 24.886 34.8818 23.1188 35.1176C17.6073 35.8507 10.4334 38.0898 7.56159 44.6025C6.84504 46.225 4.79738 58.1792 5.01262 62.2113C6.23046 66.4082 9.63191 74.3161 13.4185 78.8625C13.6763 79.1722 13.7697 79.5899 13.6678 79.982C13.2628 81.5306 12.9682 83.227 12.6567 85.0228C12.2658 87.2847 11.8608 89.6175 11.1981 91.7771C11.0367 92.3056 10.558 92.6608 10.0086 92.6608C9.88397 92.6608 9.75936 92.6409 9.64041 92.6039C8.98334 92.4022 8.61516 91.7003 8.81624 91.0411C9.43082 89.0322 9.82167 86.776 10.2012 84.5938C10.4816 82.9684 10.7478 81.434 11.1018 79.9678C7.1934 75.0208 3.77213 66.9623 2.57978 62.7711C2.55712 62.6887 2.54013 62.6006 2.53446 62.5125C2.24841 58.3412 4.33856 45.7334 5.28168 43.5938C7.9241 37.6011 13.9793 33.8134 22.7902 32.6427C24.6595 32.3954 26.642 32.2676 28.6868 32.2676C36.0986 32.2676 41.9867 33.8446 44.1732 34.5237C45.6997 34.9983 46.9799 36.2542 47.9796 38.2575C51.2055 44.7219 51.1064 58.6083 47.7729 67.9767C45.3854 74.6798 38.3927 79.6694 32.8813 82.6985C32.2186 85.557 31.4907 88.623 30.8733 91.1377C30.1463 94.1099 29.5893 95.6898 29.2023 95.8773C29.0324 95.9598 28.8511 96.0024 28.6613 96.0024L28.667 95.9995Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M47.64 0.852539H13.1469C11.2777 0.852539 9.76245 2.3728 9.76245 4.24813V67.8323C9.76245 69.7077 11.2777 71.2279 13.1469 71.2279H47.64C49.5092 71.2279 51.0245 69.7077 51.0245 67.8323V4.24813C51.0245 2.3728 49.5092 0.852539 47.64 0.852539Z"
                      fill="#46BDFF"
                    />
                    <path
                      d="M25.9769 67.0367C25.2887 67.0367 24.7307 66.4769 24.7307 65.7864C24.7307 65.0959 25.2887 64.5361 25.9769 64.5361H34.8076C35.4958 64.5361 36.0538 65.0959 36.0538 65.7864C36.0538 66.4769 35.4958 67.0367 34.8076 67.0367H25.9769Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M51.0018 7.41016H9.75391V61.1542H51.0018V7.41016Z"
                      fill="white"
                    />
                    <path
                      d="M10.7452 62.0071C10.057 62.0071 9.49902 61.4473 9.49902 60.7569C9.49902 60.0664 10.057 59.5066 10.7452 59.5066H50.0389C50.7271 59.5066 51.285 60.0664 51.285 60.7569C51.285 61.4473 50.7271 62.0071 50.0389 62.0071H10.7452Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M10.7452 9.06692C10.057 9.06692 9.49902 8.50715 9.49902 7.81667C9.49902 7.12618 10.057 6.56641 10.7452 6.56641H50.0389C50.7271 6.56641 51.285 7.12618 51.285 7.81667C51.285 8.50715 50.7271 9.06692 50.0389 9.06692H10.7452Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M13.147 72.0803C10.8104 72.0803 8.91284 70.1736 8.91284 67.8294V4.25088C8.91284 1.90664 10.8132 0 13.147 0H47.6373C49.9738 0 51.8714 1.90664 51.8714 4.25088V67.8322C51.8714 70.1765 49.971 72.0831 47.6373 72.0831H13.147V72.0803ZM13.147 2.50052C12.1868 2.50052 11.4052 3.28477 11.4052 4.24804V67.8294C11.4052 68.7927 12.1868 69.5769 13.147 69.5769H47.6373C48.5974 69.5769 49.379 68.7927 49.379 67.8294V4.25088C49.379 3.28761 48.5974 2.50336 47.6373 2.50336H13.147V2.50052Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M50.427 55.5598C48.7588 55.5598 47.3739 54.1703 46.8953 52.0164C46.3288 49.4704 47.7647 47.4104 50.6366 46.6375C51.1973 46.4869 51.7326 46.4102 52.2283 46.4102C53.4093 46.4102 54.3326 46.8477 54.8962 47.6803C55.2757 48.2401 56.6606 50.877 55.9554 52.6188C55.5079 53.7185 54.0295 54.3237 52.7239 54.8579C52.401 54.9886 52.098 55.1137 51.8261 55.2387C51.3616 55.4518 50.8886 55.5598 50.427 55.5598Z"
                      fill="white"
                    />
                    <path
                      d="M50.4266 56.4121C48.345 56.4121 46.6343 54.7584 46.065 52.201C45.3995 49.2118 47.1073 46.7027 50.4153 45.8134C51.0468 45.6429 51.6558 45.5576 52.2279 45.5576C53.7034 45.5576 54.8703 46.1259 55.5982 47.2C56.1618 48.0297 57.5835 50.8655 56.7424 52.937C56.1618 54.3691 54.5078 55.0454 53.0464 55.6449C52.7292 55.7756 52.4346 55.895 52.1797 56.0115C51.602 56.2757 51.0129 56.4121 50.4266 56.4121ZM52.2279 48.0581C51.8738 48.0581 51.483 48.115 51.061 48.2286C49.8885 48.544 47.9966 49.4078 48.4979 51.6583C48.8009 53.0279 49.56 53.9116 50.4266 53.9116C50.6532 53.9116 50.8939 53.8548 51.1403 53.7383C51.4405 53.5991 51.7577 53.4712 52.0891 53.3348C52.8509 53.0222 54.2472 52.4511 54.4313 51.9965C54.757 51.1895 53.9697 49.2459 53.5363 48.6094C53.3777 48.3735 53.0662 48.061 52.2279 48.061V48.0581Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M49.807 63.4645C49.1188 63.4645 48.5071 63.2769 47.884 62.8734C47.0881 62.3591 46.3376 61.1657 46.0997 60.3559C45.7712 59.2477 45.9071 57.8355 46.4311 56.9205C47.0796 55.7868 48.2748 55.4287 49.6597 55.0167C50.4414 54.7837 51.461 54.5166 52.4041 54.5166C52.8771 54.5166 53.3019 54.5848 53.6616 54.7212C54.7209 55.1218 55.4402 56.0055 55.8594 57.4235C55.9274 57.6593 56.0237 57.898 56.1171 58.131C56.4287 58.9152 56.7827 59.8046 56.1511 60.6883C55.4062 61.7312 53.2425 62.6774 51.9708 63.0553C51.2571 63.2684 50.5037 63.4645 49.807 63.4645Z"
                      fill="white"
                    />
                    <path
                      d="M49.8068 64.317C48.9486 64.317 48.1924 64.0869 47.4249 63.5924C46.4166 62.9389 45.5698 61.5636 45.2838 60.6003C44.8929 59.2876 45.06 57.5997 45.6916 56.5001C46.5073 55.0708 47.9857 54.6303 49.4159 54.2041C50.2542 53.9541 51.3503 53.6699 52.4039 53.6699C52.9788 53.6699 53.5028 53.758 53.9616 53.9285C55.27 54.4229 56.182 55.5169 56.6748 57.1849C56.7343 57.3838 56.8164 57.594 56.907 57.8185C57.2412 58.6567 57.7454 59.9241 56.8419 61.1885C55.6694 62.8309 52.3529 63.834 52.2141 63.8766C51.4381 64.1067 50.6111 64.3199 49.8096 64.3199L49.8068 64.317ZM52.4039 56.1648C51.6618 56.1648 50.747 56.412 50.1268 56.5967C48.7702 57.0002 48.1471 57.2332 47.8554 57.7418C47.558 58.2618 47.4787 59.2222 47.6741 59.8871C47.8356 60.4327 48.3907 61.2425 48.7758 61.4897C49.1355 61.7227 49.4329 61.8165 49.8068 61.8165C50.2004 61.8165 50.6904 61.717 51.5032 61.4755C52.8768 61.0663 54.4572 60.2338 54.8169 59.728C54.8934 59.6229 54.8934 59.4978 54.5931 58.742C54.4855 58.4721 54.3751 58.1964 54.2873 57.8895C54.021 56.9888 53.6387 56.4716 53.0864 56.2642C52.9108 56.1989 52.6814 56.1648 52.4067 56.1648H52.4039Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M48.963 70.9952C48.6543 70.9952 48.3654 70.9497 48.0737 70.8559C47.0682 70.532 46.5499 69.5943 46.1393 68.631C45.7399 67.699 45.6805 66.7017 45.9693 65.8208C46.2781 64.8803 46.9804 64.133 47.9462 63.7181C48.3172 63.559 51.6139 62.1553 52.5966 62.1553C52.6335 62.1553 52.6703 62.1553 52.7014 62.161C54.194 62.3172 54.7293 63.5675 55.1201 64.4796C55.5789 65.5537 55.9556 66.7926 55.2957 67.8383C54.7803 68.6595 51.2174 70.3644 50.8492 70.5235C50.3366 70.7423 49.6597 70.9952 48.963 70.9952Z"
                      fill="white"
                    />
                    <path
                      d="M48.9627 71.8476C48.5719 71.8476 48.1839 71.788 47.8129 71.6658C46.4846 71.2367 45.8473 70.1143 45.3574 68.9663C44.8787 67.844 44.8079 66.6306 45.162 65.5537C45.55 64.3773 46.4195 63.4482 47.6118 62.9367C48.7532 62.4451 51.5259 61.3057 52.5964 61.3057C52.6644 61.3057 52.7295 61.3085 52.789 61.3142C54.7772 61.5216 55.4824 63.164 55.9016 64.1443C56.2584 64.9854 57.0033 66.7301 56.0149 68.2958C55.2842 69.4636 51.2228 71.2907 51.1832 71.3077C50.5997 71.5578 49.8181 71.8476 48.9627 71.8476ZM52.5596 63.8033C52.2056 63.8289 50.3958 64.4597 48.5946 65.2355C48.0621 65.4656 47.6939 65.8464 47.5325 66.3408C47.3682 66.8381 47.4107 67.4206 47.6514 67.9832C47.9092 68.5884 48.2009 69.1652 48.5804 69.2874C48.7135 69.3301 48.8381 69.3499 48.9712 69.3499C49.2715 69.3499 49.6538 69.2448 50.2032 69.009C51.2795 68.5486 53.5509 67.2955 53.9304 66.9176C54.0975 66.5965 53.9984 66.0396 53.6075 65.1275C53.1515 64.0648 52.9391 63.8516 52.5568 63.8033H52.5596Z"
                      fill="#355CF3"
                    />
                    <path
                      d="M4.16377 64.8711C3.96269 64.3653 3.83524 63.9505 3.67664 63.4219C3.59734 63.1605 3.51237 62.8764 3.40475 62.5439C1.97166 58.0799 0.479104 52.9652 0.932253 48.7399C1.139 47.5777 1.3146 45.8899 1.51851 43.9349C2.04813 38.8629 2.64855 33.1145 4.15244 31.6028C4.98227 30.6538 6.11231 30.1338 7.34148 30.1338C9.27586 30.1338 10.8789 31.4125 11.0658 33.1117C11.5444 37.4364 9.44862 47.3135 9.36082 47.7312L4.60842 65.9963L4.16094 64.8739L4.16377 64.8711Z"
                      fill="white"
                    />
                    <path
                      d="M4.53175 65.9771C4.01913 65.9771 3.56314 65.6673 3.37339 65.19C3.15814 64.6501 3.0222 64.1983 2.8636 63.6754C2.78713 63.4169 2.70216 63.1384 2.59454 62.8088C1.13313 58.2596 -0.384916 53.0426 0.088058 48.6496C0.0908902 48.6212 0.0965545 48.5928 0.0993867 48.5644C0.294807 47.4619 0.478899 45.7058 0.67432 43.8475C1.37387 37.1444 1.95163 32.6292 3.54049 31.0124C4.50626 29.9128 5.89403 29.2734 7.33278 29.2734C7.8454 29.2734 8.36086 29.353 8.85932 29.5093C10.5615 30.0435 11.734 31.3875 11.9124 33.0128C12.408 37.4825 10.2839 47.4818 10.1933 47.9051C10.0715 48.4763 9.55887 48.894 8.97544 48.894C8.88764 48.894 8.79985 48.8855 8.71488 48.8656C8.38918 48.7945 8.1088 48.6013 7.92754 48.3228C7.74628 48.0415 7.6868 47.7091 7.75477 47.3823C7.77743 47.2829 9.88174 37.3376 9.43426 33.2913C9.35212 32.544 8.69789 32.0808 8.11446 31.8961C7.87372 31.8194 7.6075 31.7796 7.34411 31.7796C6.81166 31.7796 6.0413 31.9388 5.38424 32.6946C5.36441 32.7173 5.34175 32.7401 5.3191 32.7628C4.22587 33.8426 3.55465 40.2672 3.15531 44.1032C2.94856 46.0752 2.77297 47.7773 2.56055 48.9679C2.15272 52.8408 3.58863 57.7452 4.96791 62.0331C5.07836 62.3769 5.16616 62.6696 5.24829 62.9367C5.39557 63.4282 5.51452 63.8147 5.69011 64.2551C5.94501 64.8945 5.63347 65.6247 4.99623 65.8805C4.84612 65.9401 4.69318 65.9714 4.53458 65.9714L4.53175 65.9771Z"
                      fill="#355CF3"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_259_2023">
                      <rect width={59} height={96} fill="white" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
              <div className="stepText">
                <span>STEP.5</span>
                <p>センターモバイルのご利用開始</p>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </section>
    <section id="qa">
      <div className="container">
        <h2>よくあるご質問</h2>
        <div className="accordion">
          <div className="accordion-item">
            <div className="accordion-title">
              <p>最大で0円まで割引ってどういうこと？</p>
              <span />
            </div>
            <div className="accordion-content">
              <p>
                お客様が会員専用アプリからスポンサーの広告を見たり、サービスを利用することで、弊社に広告収入が発生します。その広告収入をポイントとしてお客様に還元。お客様はポイントを携帯料金に利用することで、最大割引で0円にすることが可能です。
              </p>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-title">
              <p>どのような広告でポイントが貯まりますか？</p>
              <span />
            </div>
            <div className="accordion-content">
              <p>
                動画広告を見るだけでなく、ガチャを回すことでの大量ポイント獲得や、アプリダウンロード、商品の購入、サービス利用申込みでもポイントが貯まります。PLAIO
                WiMAXなど、セットで申込をすればさらに効率よくポイントの獲得ができます。
              </p>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-title">
              <p>郊外に住んでいるのですが、電波は届きますか？</p>
              <span />
            </div>
            <div className="accordion-content">
              <p>
                センターモバイルでは安心のdocomo回線を利用しています。旅先や出張中で郊外に出ても、docomoの電波が届く場所なら問題なくご使用いただけます。
              </p>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-title">
              <p>
                格安SIMについてもうちょっと詳しく話を聞きながら相談したいです。
              </p>
              <span />
            </div>
            <div className="accordion-content">
              <p>
                センターモバイルは全国各地に店舗を構えております。ぜひお近くの店舗でご相談ください。
              </p>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-title">
              <p>申込みをしてからどのくらいで切り替えができますか？</p>
              <span />
            </div>
            <div className="accordion-content">
              <p>
                店舗でのお申込みの場合はeSIMでも通常SIMでも即日可能。
                <br />
                WEBからのお申込みの場合、eSIMは即日可能、通常SIMは7日前後でSIMカードを発送いたします。
              </p>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-title">
              <p>支払い方法はどのような方法がありますか？</p>
              <span />
            </div>
            <div className="accordion-content">
              <p>
                atone後払い決済・クレジットカード・デビットカードのいずれかが利用可能です。
                <br />
                atone後払いでは、振込や支払い用紙のよる「翌月払い」と「つど払い」をお選びいただけます。「翌月払い」の場合、口座振替が可能です。※デビットカードは一部ご利用できない場合がございます。
              </p>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-title">
              <p>契約に料金はかかりますか？</p>
              <span />
            </div>
            <div className="accordion-content">
              <p>初回のみSIM発行料として3,733円がかかります。</p>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-title">
              <p>今のスマホそのまま使えますか？</p>
              <span />
            </div>
            <div className="accordion-content">
              <p>
                SIMカードを入れ替えるか、eSIMを設定いただくだけで、現在お使いの機種をそのまま利用することができます。
                <br />
                ※端末によってはSIMロック解除が必要な場合がございますので、お使いの端末が対象か必ずご確認ください。
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <ApplyButtonSecond/>
    <footer>
      <div className="container">
        <p>Copyright (C) CENTER MOBILE All rights reserved.</p>
      </div>
    </footer>
  </>
  )
}

export default Offpeak;