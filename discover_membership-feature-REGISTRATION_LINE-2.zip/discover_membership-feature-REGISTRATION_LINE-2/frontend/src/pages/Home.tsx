
import { useQuery } from 'react-query'

function Home(){
  const fetchingMessage = async (): Promise<string> => {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({name: "test"})
    };
    const resp = await fetch(process.env.REACT_APP_API_URL+  '/hello', requestOptions);
    const { message } = await resp.json();
    return message;
  }

  const { data } = useQuery('query-message', fetchingMessage)
  return (
    <>
      <h1 className="text-3xl text-blue-600 font-bold">
        Home
      </h1>
      <p>
        api resp: {data}
      </p>
    </>
  );
}

export default Home