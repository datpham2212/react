import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Offpeak from './pages/Offpeak';
import NotFound from './pages/NotFound';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/offpeak" element={<Offpeak />} />
        {/* Error route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
