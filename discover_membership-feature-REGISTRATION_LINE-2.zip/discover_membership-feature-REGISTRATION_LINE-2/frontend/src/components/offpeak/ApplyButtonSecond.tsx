import React from 'react';
import { checkQueryParamValue } from '../../utils/common';

const ApplyButtonSecond: React.FC = () => {
  // 特定のGETパラメーターの名前
  const specificParam = 'source';

  // クエリパラメーターが条件に一致するかどうかを確認
  const shouldShowButton = !checkQueryParamValue(specificParam, 'membership');

  // 特定のGETパラメーターが存在し、かつその値が条件と一致する場合にボタンを表示
  return shouldShowButton ? (
    <div id="btn-kochira">
      <div className="btn">
        <a
          href="https://maimo.app/app_member/f0d11b60c874bd4c4ee2?af=400f98352d694e0T&plan=offpeak"
          target="_blank"
        >
          <div className="kikan">
            <img
              src={require("../../assets/images/lp/offpeak/sim-Btn.png")}
              width="100%"
              alt="通話SIMが月額935円（税込）〜　オフピークプランのお申込みはこちら"
            />
          </div>
        </a>
      </div>
    </div>
  ) : null;
};

export default ApplyButtonSecond;

