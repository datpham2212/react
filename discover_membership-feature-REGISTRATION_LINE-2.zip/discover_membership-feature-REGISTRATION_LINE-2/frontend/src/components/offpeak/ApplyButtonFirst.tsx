import React from 'react';
import { checkQueryParamValue } from '../../utils/common';

interface ApplyButtonProps {
  urlPram?: Boolean;
}

const ApplyButtonFirst: React.FC<ApplyButtonProps> = ({ urlPram = false }) => {
  // 特定のGETパラメーターの名前
  const specificParam = 'source';

  // クエリパラメーターが条件に一致するかどうかを確認
  const shouldShowButton = !checkQueryParamValue(specificParam, 'membership');

  // 特定のGETパラメーターが存在し、かつその値が条件と一致する場合に申し込みボタンを表示
  return shouldShowButton ? (
    <div className="btn">
      <a
        href={`https://maimo.app/app_member/f0d11b60c874bd4c4ee2?af=400f98352d694e0T${urlPram ? `&plan=offpeak` : ''
          }`}
        target="_blank"
      >
        今すぐ申し込む！
      </a>
    </div>
  ) : null;
};

export default ApplyButtonFirst;
